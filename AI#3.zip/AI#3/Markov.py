class word_object:
    def __init__(self, word, count, hashtable):
        self.word = word
        self.count = count
        self.hashtable = hashtable

    def __str__(self):
        return str(self.word) + "," + str(self.count)


def check_word_in_hashtable(word, hashtable):
    for key in hashtable.keys():
        if key == word:
            return hashtable[key]
    return False


class Markov:
    def __init__(self):
        self.hashtable = {}

    # inserting the monogram remember to do this for the last word as well
    def insert_mono(self, word):
        check = check_word_in_hashtable(word, self.hashtable)
        if not check:
            first_word_object = word_object(word, 1, {})
            self.hashtable[word] = first_word_object
        else:
            check.count += 1

    # inserting the bigram remember to do this for the second to last word plus the last word as well
    def insert_bi(self, word, next_word):
        check = check_word_in_hashtable(next_word, self.hashtable[word].hashtable)
        if not check:
            second_word_object = word_object(next_word, 1, {})
            self.hashtable[word].hashtable[next_word] = second_word_object
        else:
            check.count += 1

    # inserting a trigram most used insert also remember to call previous methods for this method to work
    def insert_tri(self, word, next_word, third_word):
        check = check_word_in_hashtable(third_word, self.hashtable[word].hashtable[next_word].hashtable)
        if not check:
            third_word_object = word_object(third_word, 1, {})
            self.hashtable[word].hashtable[next_word].hashtable[third_word] = third_word_object
        else:
            check.count += 1

    # inserting all three words at once
    def insert_all_three_words_at_once(self, word, next_word, third_word):
        self.insert_mono(word)
        self.insert_bi(word, next_word)
        self.insert_tri(word, next_word, third_word)

    def get_probability_tri(self, word, next_word, third_word):
        third_word_given_second_first = check_word_in_hashtable(third_word,
                                                                self.hashtable[word].hashtable[next_word].hashtable)
        all_possible_next_words = self.get_max_tri(word, next_word)
        return third_word_given_second_first.count / all_possible_next_words

    def get_probability_bi(self, word, next_word):
        second_word_given_first = check_word_in_hashtable(next_word, self.hashtable[word].hashtable)
        first_word = self.get_max_bi(word)
        #print(second_word_given_first.count)
        return second_word_given_first.count / first_word

    def get_max_bi(self, word):
        count = 0
        for x in self.hashtable[word].hashtable.keys():
            count += self.hashtable[word].hashtable[x].count
        return count

    def get_max_tri(self, word, next_word):
        count = 0
        for x in self.hashtable[word].hashtable[next_word].hashtable.keys():
            count += self.hashtable[word].hashtable[next_word].hashtable[x].count
        return count

    def get_best_possible_bi(self, word):
        best_count = 0, 0
        for x in self.hashtable[word].hashtable.keys():
            if self.get_probability_bi(word, self.hashtable[word].hashtable[x].word) > best_count[1]:
                best_count = self.hashtable[word].hashtable[x].word, self.get_probability_bi(word, self.hashtable[
                    word].hashtable[x].word)
        return best_count[0]

    def get_best_possible_tri(self, word, next_word):
        best_count = 0, 0
        for x in self.hashtable[word].hashtable[next_word].hashtable.keys():
            if self.get_probability_tri(word, self.hashtable[word].hashtable[next_word].word,
                                        self.hashtable[word].hashtable[next_word].hashtable[x].word) > best_count[1]:
                best_count = self.hashtable[word].hashtable[next_word].hashtable[x].word, self.get_probability_tri(word,
                                                                                                                   self.hashtable[
                                                                                                                       word].hashtable[
                                                                                                                       next_word].word,
                                                                                                                   self.hashtable[
                                                                                                                       word].hashtable[
                                                                                                                       next_word].hashtable[
                                                                                                                       x].word)
        return best_count[0]



