import random

from Markov import Markov

file = ["houn.txt", "sign.txt", "stud.txt", "vall.txt"]


# Python program to remove punctuation from a given string
# Function to remove punctuation
def Punctuation(string):
    # punctuation marks
    punctuations = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''

    # traverse the given string and if any punctuation
    # marks occur replace it with null
    for x in string.lower():
        if x in punctuations:
            string = string.replace(x, "")
    return string


def main(file1, file2):
    markov_model = Markov()
    put_contents_in(file1, markov_model)
    put_contents_in(file2, markov_model)
    write = open("Readme.txt", "w")
    word = random.choice(list(markov_model.hashtable))
    write.write(word + " ")
    for y in range(0, 100):
        for x in range(0, 10):
            if x % 3 == 0:
                word = random.choice(list(markov_model.hashtable))
            tri_gram = create_new_tri_rand(markov_model, word)
            write.write(tri_gram[0])
            word = tri_gram[1]
        write.write("\n")
    write.close()


def create_new_tri_rand(markov_model, new_word):
    best_bi = markov_model.get_best_possible_bi(new_word)
    if best_bi != 0:
        best_tri = markov_model.get_best_possible_tri(new_word, best_bi)
        if best_tri == 0:
            best_tri = random.choice(list(markov_model.hashtable))
    else:
        best_bi = random.choice(list(markov_model.hashtable))
        best_tri = random.choice(list(markov_model.hashtable))
    return str(best_bi + " " + best_tri + " "), best_tri


def put_contents_in(file_part, markov_model):
    with open(file[file_part], 'r') as f:
        lines = f.read()
        phrase_split = lines.split(".")
        # print(lines.split("."))
        for phrase in range(0, len(phrase_split) - 1):
            punctuation = Punctuation(phrase_split[phrase])
            splited = punctuation.split()
            for x in range(0, len(splited) - 2):
                markov_model.insert_all_three_words_at_once(splited[x], splited[x + 1], splited[x + 2])
            markov_model.insert_mono(splited[len(splited) - 2])
            markov_model.insert_bi(splited[len(splited) - 2], splited[len(splited) - 1])
            markov_model.insert_mono(splited[len(splited) - 1])


main(0, 1)
